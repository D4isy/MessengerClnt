// Room.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "MessaengerClient.h"
#include "Room.h"
#include "afxdialogex.h"

class CCustomListCtl : public CListCtrl
{
public:
	CCustomListCtl();

protected:
	DECLARE_MESSAGE_MAP()
};

CCustomListCtl::CCustomListCtl() {

}

// CRoom ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CRoom, CDialogEx)

CRoom::CRoom(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_ROOM, pParent)
{

}

CRoom::~CRoom()
{
}

void CRoom::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CRoom, CDialogEx)
END_MESSAGE_MAP()


// CRoom �޽��� ó�����Դϴ�.
