//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// MessaengerClient.rc���� ���ǰ� �ֽ��ϴ�.
//
#define ID_TALKLIST                     2
#define ID_ACC_SEARCH                   3
#define ID_FRIENDLIST                   3
#define ID_ROOMMAKE                     5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MESSAENGERCLIENT_DIALOG     102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     130
#define IDD_LOBBY                       130
#define IDD_FRIENDLIST                  132
#define IDD_ROOM                        133
#define IDD_TABCTL                      136
#define EDIT_ID                         1000
#define EDIT_PASS                       1001
#define STATIC_ID                       1002
#define STATIC_PASS                     1003
#define ID_LOGIN                        1004
#define ID_REGISTER                     1005
#define LIST_ROOM                       1007
#define LIST_WHISPER                    1018
#define LIST_TALKINGROOM                1019
#define ID_ROOM_EXIT                    1020
#define EDIT_FRIENDNAME                 1021
#define TREE_FRIEND                     1023
#define ID_FRIEND_ADD                   1025
#define ID_FRIEND_DEL                   1026
#define TAB_ROOMLIST                    1027
#define IDC_MFCLINK1                    1070

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1071
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
